import { useRouter } from 'expo-router';
import { ProfilScreen } from '@/screens/ProfilScreen';

/** Route Profil — tab 5. Menghubungkan ProfilScreen dengan navigasi (keluar ke layar awal). */
export default function ProfilRoute() {
  const router = useRouter();

  return <ProfilScreen onLogout={() => router.replace('/screenawal')} />;
}
