import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useSheetDraft } from '@/hooks/use-sheet-draft';
import type { StaffMember } from '@/types/profile';
import { isValidEmail } from '@/utils/service';
import { Button, Input } from '../atoms';
import { BottomSheet, FormField, InfoNote } from '../molecules';

export interface StaffFormInput {
  name: string;
  email: string;
}

interface StaffFormSheetProps {
  visible: boolean;
  /** Kosong = mode tambah staf; terisi = mode ubah data staf. */
  staff: StaffMember | null;
  onClose: () => void;
  onSave: (input: StaffFormInput) => void;
  onToggleStatus: (id: string) => void;
}

const EMPTY: StaffFormInput = { name: '', email: '' };

/** Sheet "Tambah Staf" / "Ubah Staf" — hanya dapat dibuka oleh Notaris (PRD §12). */
export function StaffFormSheet({
  visible,
  staff,
  onClose,
  onSave,
  onToggleStatus,
}: StaffFormSheetProps) {
  const initial = staff ? { name: staff.name, email: staff.email } : EMPTY;
  const [draft, setDraft] = useSheetDraft(visible, initial);

  const nameEmpty = draft.name.trim().length === 0;
  const emailInvalid = !isValidEmail(draft.email);
  const showEmailError = emailInvalid && draft.email.length > 0;

  const save = () => {
    onSave({ name: draft.name.trim(), email: draft.email.trim() });
    onClose();
  };

  const toggleStatus = () => {
    if (!staff) return;
    onToggleStatus(staff.id);
    onClose();
  };

  return (
    <BottomSheet visible={visible} onClose={onClose} title={staff ? 'Ubah Staf' : 'Tambah Staf'}>
      <View style={styles.form}>
        <FormField label="Nama staf" required>
          <Input
            value={draft.name}
            onChangeText={(name) => setDraft({ ...draft, name })}
            placeholder="Masukkan nama staf"
            autoCapitalize="words"
            accessibilityLabel="Nama staf"
          />
        </FormField>

        <FormField
          label="Email"
          required
          error={showEmailError ? 'Format email belum valid' : undefined}>
          <Input
            value={draft.email}
            onChangeText={(email) => setDraft({ ...draft, email })}
            placeholder="Masukkan email"
            invalid={showEmailError}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            accessibilityLabel="Email"
          />
        </FormField>

        <InfoNote
          tone="neutral"
          icon="information-circle-outline"
          text="Staf memiliki akses operasional. Persetujuan dan pengelolaan staf hanya untuk Notaris."
        />

        <Button
          label={staff ? 'Simpan Perubahan' : 'Tambah Staf'}
          disabled={nameEmpty || emailInvalid}
          onPress={save}
        />

        {staff ? (
          <Button
            label={staff.status === 'Aktif' ? 'Nonaktifkan Staf' : 'Aktifkan Staf'}
            variant="outline"
            onPress={toggleStatus}
          />
        ) : null}
      </View>
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  form: { gap: 16 },
});
