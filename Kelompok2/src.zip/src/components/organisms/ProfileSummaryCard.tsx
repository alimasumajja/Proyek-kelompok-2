import React from 'react';
import { StyleSheet, View } from 'react-native';
import { NotaryColors, Radius, Shadow } from '@/constants/notary-theme';
import type { UserRole } from '@/types/service';
import { AppText, Avatar, Badge } from '../atoms';

interface ProfileSummaryCardProps {
  name: string;
  email: string;
  role: UserRole;
}

const ROLE_LABEL: Record<UserRole, { title: string; access: string }> = {
  Notaris: { title: 'Notaris', access: 'Akses Penuh' },
  Staf: { title: 'Staf Kantor', access: 'Akses Operasional' },
};

/** Kartu identitas pengguna di bagian atas halaman Profil. */
export function ProfileSummaryCard({ name, email, role }: ProfileSummaryCardProps) {
  const label = ROLE_LABEL[role];
  return (
    <View style={styles.card}>
      <Avatar name={name} size="lg" tone="soft" />
      <View style={styles.texts}>
        <AppText variant="display" style={styles.center}>
          {name}
        </AppText>
        <AppText variant="bodyStrong" color={NotaryColors.textSecondary}>
          {label.title}
        </AppText>
        <AppText variant="caption" color={NotaryColors.textMuted}>
          {email}
        </AppText>
      </View>
      <Badge
        label={label.access}
        tone={role === 'Notaris' ? 'gold' : 'info'}
        icon={role === 'Notaris' ? 'shield-checkmark' : 'shield-outline'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    gap: 14,
    padding: 24,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: NotaryColors.border,
    backgroundColor: '#FFFFFF',
    ...Shadow.card,
  },
  texts: { alignItems: 'center', gap: 4 },
  center: { textAlign: 'center' },
});

