import type { UserRole } from './service';

/** Status akun staf. Label teks selalu ditampilkan, tidak hanya warna (PRD §13.3). */
export type StaffStatus = 'Aktif' | 'Nonaktif';

/** Peran yang dapat diberikan saat menambah staf. Notaris hanya satu (pemilik kantor). */
export type StaffRole = Extract<UserRole, 'Staf'>;

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  initials: string;
  role: StaffRole;
  status: StaffStatus;
}

/** Data akun yang dapat diubah pengguna di Profil. */
export interface AccountInfo {
  name: string;
  email: string;
}

/** Preferensi notifikasi — PRD §6.9. */
export interface NotificationPrefs {
  deadlineNear: boolean;
  newIssue: boolean;
  noUpdate: boolean;
}
