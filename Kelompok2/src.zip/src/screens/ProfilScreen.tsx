import React, { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { NotaryColors, Radius } from '@/constants/notary-theme';
import { useProfileStore } from '@/context/profile-store';
import { useServiceStore } from '@/context/service-store';
import { useToast } from '@/context/toast';
import { useStatusBarStyle } from '@/hooks/use-status-bar-style';
import type { StaffMember } from '@/types/profile';
import { AppText, Button } from '@/components/atoms';
import { ActionListItem, ConfirmDialog, StaffRow } from '@/components/molecules';
import {
  AccountInfoSheet,
  AppHeader,
  NotificationSettingsSheet,
  ProfileSummaryCard,
  RoleDemoCard,
  StaffFormSheet,
} from '@/components/organisms';

interface ProfilScreenProps {
  /** Dipanggil setelah pengguna mengonfirmasi keluar (navigasi diatur oleh route). */
  onLogout: () => void;
}

/**
 * Halaman Profil — PRD §4.1 dan §12 (Hak Akses): informasi akun, manajemen staf
 * (hanya Notaris), pengaturan notifikasi, Mode Demo peran, dan keluar.
 * State akun/staf dari profile-store; peran dari service-store (berlaku di seluruh aplikasi).
 */
export function ProfilScreen({ onLogout }: ProfilScreenProps) {
  useStatusBarStyle('dark');
  const insets = useSafeAreaInsets();
  const { showToast } = useToast();
  const { role, setRole } = useServiceStore();
  const {
    account,
    staff,
    notificationPrefs,
    updateAccount,
    addStaff,
    updateStaff,
    toggleStaffStatus,
    saveNotificationPrefs,
  } = useProfileStore();

  const [accountOpen, setAccountOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [staffOpen, setStaffOpen] = useState(false);
  const [staffFormOpen, setStaffFormOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [logoutOpen, setLogoutOpen] = useState(false);

  const isNotaris = role === 'Notaris';

  const openAddStaff = () => {
    setEditingStaff(null);
    setStaffFormOpen(true);
  };

  const openEditStaff = (member: StaffMember) => {
    setEditingStaff(member);
    setStaffFormOpen(true);
  };

  const changeRole = (next: typeof role) => {
    setRole(next);
    if (next !== 'Notaris') setStaffOpen(false); // Manajemen Staf hanya untuk Notaris
  };

  return (
    <View style={styles.screen}>
      <AppHeader title="Profil" />

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 110 }]}
        showsVerticalScrollIndicator={false}>
        <ProfileSummaryCard name={account.name} email={account.email} role={role} />

        <View style={styles.section}>
          <AppText variant="eyebrow" color={NotaryColors.textSecondary}>
            PENGATURAN
          </AppText>
          <ActionListItem
            icon="person-outline"
            title="Informasi Akun"
            description="Nama dan email akun"
            onPress={() => setAccountOpen(true)}
          />
          {isNotaris ? (
            <ActionListItem
              icon="people-outline"
              title="Manajemen Staf"
              description={`${staff.length} staf terdaftar`}
              onPress={() => setStaffOpen((open) => !open)}
            />
          ) : null}
          <ActionListItem
            icon="notifications-outline"
            title="Notifikasi"
            description="Pengaturan pemberitahuan"
            onPress={() => setNotifOpen(true)}
          />
        </View>

        {isNotaris && staffOpen ? (
          <View style={styles.section}>
            <View style={styles.staffHeader}>
              <AppText variant="eyebrow" color={NotaryColors.textSecondary}>
                DAFTAR STAF
              </AppText>
              <Button label="Tambah" icon="add" compact onPress={openAddStaff} />
            </View>
            <View style={styles.staffList}>
              {staff.map((member, index) => (
                <StaffRow
                  key={member.id}
                  staff={member}
                  onPress={openEditStaff}
                  showDivider={index < staff.length - 1}
                />
              ))}
            </View>
          </View>
        ) : null}

        <View style={styles.section}>
          <AppText variant="eyebrow" color={NotaryColors.textSecondary}>
            MODE DEMO
          </AppText>
          <RoleDemoCard role={role} onChange={changeRole} />
        </View>

        <Button
          label="Keluar"
          icon="log-out-outline"
          variant="outline"
          onPress={() => setLogoutOpen(true)}
        />
      </ScrollView>

      <AccountInfoSheet
        visible={accountOpen}
        account={account}
        onClose={() => setAccountOpen(false)}
        onSave={(next) => {
          updateAccount(next);
          showToast('Informasi akun diperbarui');
        }}
      />
      <NotificationSettingsSheet
        visible={notifOpen}
        prefs={notificationPrefs}
        onClose={() => setNotifOpen(false)}
        onSave={(next) => {
          saveNotificationPrefs(next);
          showToast('Pengaturan notifikasi disimpan');
        }}
      />
      <StaffFormSheet
        visible={staffFormOpen}
        staff={editingStaff}
        onClose={() => setStaffFormOpen(false)}
        onSave={({ name, email }) => {
          if (editingStaff) {
            updateStaff(editingStaff.id, { name, email });
            showToast('Data staf diperbarui');
          } else {
            addStaff({ name, email, role: 'Staf' });
            showToast('Staf baru ditambahkan');
          }
        }}
        onToggleStatus={(id) => {
          toggleStaffStatus(id);
          showToast('Status staf diperbarui');
        }}
      />
      <ConfirmDialog
        visible={logoutOpen}
        title="Keluar dari akun?"
        text="Anda perlu masuk kembali untuk mengakses layanan kantor."
        confirmLabel="Ya, Keluar"
        onCancel={() => setLogoutOpen(false)}
        onConfirm={() => {
          setLogoutOpen(false);
          onLogout();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: NotaryColors.background },
  content: { gap: 20, paddingHorizontal: 16, paddingTop: 16 },
  section: { gap: 10 },
  staffHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  staffList: {
    overflow: 'hidden',
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: NotaryColors.border,
    backgroundColor: '#FFFFFF',
  },
});
